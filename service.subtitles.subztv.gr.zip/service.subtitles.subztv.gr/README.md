======================
SubzTV addon for Kodi
======================

About
-----
Search and download subtitles from subztv.gr

Kodi Addon for http://subztv.gr/

This service is not published nor endorsed by subztv.gr


Artwork
---------------------
Artwork sourced from public domain:

http://subztv.gr/assets/images/logo.png


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html